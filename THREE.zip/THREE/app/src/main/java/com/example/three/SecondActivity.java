package com.example.three;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.zip.Inflater;

public class SecondActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);         //忘记再manifest中声明SecondActivity了
        setContentView(R.layout.second_layout);
        Intent intent =getIntent();
        String data = intent.getStringExtra("A");
        Log.d("传送给第二个activity的数据是",data);
        EditText shuru2 = findViewById(R.id.shuru2);
        Button bt2 = findViewById(R.id.bt2);
        shuru2.setText(data);      //将数据放入并显示出来
        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                EditText shuru2 = findViewById(R.id.shuru2);
                intent.putExtra("B",shuru2.getText().toString());        //将修改后的结果传入
                setResult(1,intent);
                finish();
            }
        });

    }
}
